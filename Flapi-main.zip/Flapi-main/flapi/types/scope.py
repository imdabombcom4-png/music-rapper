"""
# Flapi / Types / Scope
"""
from typing import Any


ScopeType = dict[str, Any]
"""
Represents a variable scope in Python
"""
